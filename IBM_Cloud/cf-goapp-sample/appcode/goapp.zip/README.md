# Go Hello World Sample

This application demonstrates a simple, reusable Go web application.

## Run the app locally

1. [Install Go][]
1. cd into this project's root directory
1. Run `go run app.go`
1. Access the running app in a browser at <http://localhost:8080>

[Install Go]: https://golang.org/doc/install
